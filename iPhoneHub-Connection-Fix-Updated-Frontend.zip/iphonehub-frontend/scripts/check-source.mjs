import ts from 'typescript';
import fs from 'node:fs';
import path from 'node:path';
let failures = 0; let checked = 0;
function scan(folder) {
  for (const name of fs.readdirSync(folder)) {
    const full = path.join(folder, name);
    if (fs.statSync(full).isDirectory()) { scan(full); continue; }
    if (!/\.(js|jsx)$/.test(name)) continue;
    const code = fs.readFileSync(full, 'utf8');
    const file = ts.createSourceFile(full, code, ts.ScriptTarget.Latest, true, name.endsWith('.jsx') ? ts.ScriptKind.JSX : ts.ScriptKind.JS);
    checked++;
    for (const e of file.parseDiagnostics) {
      failures++;
      console.error(`${full}:${file.getLineAndCharacterOfPosition(e.start).line+1} ${ts.flattenDiagnosticMessageText(e.messageText, ' ')}`);
    }
  }
}
scan(path.resolve('src'));
console.log(`Parsed ${checked} source files with ${failures} syntax errors.`);
if (failures) process.exitCode = 1;
