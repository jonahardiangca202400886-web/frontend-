# Fix: "Cannot reach the iPhoneHub server"

The original React error is from a failed `fetch`; it does not identify exactly which layer broke.

**Do this in order:**

1. **Open** https://iphone-e-commerce-application.onrender.com/api/v1/health **directly in a browser.**
   - If no JSON loads, resolve Render deployment/dns/server error FIRST. Frontend changes cannot repair a stopped service.
   - If JSON loads but the website fails, open Chrome DevTools -> Network & Console and look for a CORS error or wrong API URL.
2. In the Render **backend Web Service**, check **Root Directory = `backend`**, **Build Command = `npm install`**, **Start Command = `npm start`**. The GitHub repository root has a different `package.json` with no `start` script. Verify that the backend environment has `SUPABASE_URL`, `SUPABASE_SECRET_KEY`, `SUPABASE_PUBLISHABLE_KEY`, because `src/config/supabase.js` throws at startup if any is missing. **Never expose these secrets in the frontend.**
3. The original backend's CORS code only reads `FRONTEND_ORIGIN` (one exact origin). For a **single frontend origin**, simply set `FRONTEND_ORIGIN=http://localhost:5173` (use the **exact** host and port Vite displays) or set your live frontend URL, and redeploy.
4. To support BOTH localhost and production at once, back up your existing backend `src/server.js`; merge the CORS change from `backend-extension/connection-fix/server.js`, or copy the full file if it matches your original source. In the **backend** Render environment, set `FRONTEND_ORIGINS=http://localhost:5173,http://127.0.0.1:5173,https://YOUR-ACTUAL-FRONTEND-URL` and redeploy. Do not place this server file inside React source.
5. Inside your React project create `.env` from `.env.example`, set `VITE_API_BASE_URL=https://iphone-e-commerce-application.onrender.com`, then restart `npm run dev` (or rebuild the deployed static frontend).
6. In browser DevTools Network, make sure a request to `/api/v1/products` shows response HTTP 200. HTTP 500 means the server replied but a backend operation failed (check Supabase keys/schema/logs). HTTP 401/403 means an auth/role issue rather than a connection error.

Additional exact deployment settings and PowerShell test commands are in `backend-extension/connection-fix/README.md`.

**Test status:** Backend source and frontend source inspected; direct live Render health endpoint could not be verified from this environment. Frontend syntax + utility tests passed, but full npm build and integration tests were not possible without npm dependency download.
