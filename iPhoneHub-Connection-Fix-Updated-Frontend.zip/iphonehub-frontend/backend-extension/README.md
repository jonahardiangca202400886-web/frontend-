# Optional backend authentication patch

The existing backend's `/api/v1/auth/login` returns an access token but **not** a refresh token, and the server has no `/api/v1/auth/me`, `/refresh` or `/logout` routes. The frontend works for product browsing, initial login, customer AI and trade-ins without this patch, but **administrator pages deliberately require a verified role from `/auth/me`** and remain blocked until it is installed. The original Express `requireAdmin` middleware still protects all writes.

## Apply in your existing backend repository

1. Make a backup or commit your current `backend/src/routes/auth.js`.
2. Copy this folder's `auth.js` to `backend/src/routes/auth.js`. This is a replacement for **one route module only**; it does not replace your backend or database.
3. Ensure `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY` are configured in Render's backend environment (they should already be used by `config/supabase.js`). Do not copy any key to Vite.
4. Commit and deploy your backend. Verify `GET /api/v1/auth/me` returns `{success:true,data:{id,email,full_name,role}}` when called with a user access token. An admin must have role `admin` in `public.profiles`.
5. Test login/refresh/logout and check Supabase email-confirmation settings. `scope:'local'` revokes refresh credentials for the relevant session; existing short-lived JWTs may remain valid until expiry.
6. Set backend `FRONTEND_ORIGIN` to the deployed frontend URL. The current CORS configuration only allows one configured origin; if you need both localhost and Render, update it carefully to allowlist both.

**Important:** This replacement was source-reviewed for shape, but cannot be integration-tested here because the deployed Render host was unreachable. Verify it in your own staging environment before production. Prefer HttpOnly cookies and CSRF protections for a production-grade session implementation; this patch uses sessionStorage credentials to remain compatible with the starter API.

## Requests added by this patch

| Method | Path | Body | Authorization | Response |
|---|---|---|---|---|
| GET | `/api/v1/auth/me` | none | User Bearer token | `{success:true,data:{id,email,full_name,role}}` |
| POST | `/api/v1/auth/refresh` | `{refresh_token}` | refresh token in JSON | `{success:true,data:{access_token,refresh_token,expires_at,user}}` |
| POST | `/api/v1/auth/logout` | `{refresh_token}` | User Bearer token | `{success:true,message}` |

These new routes are **not part of the audited original backend**. Deploy the patch yourself; the frontend does not claim these already exist.
