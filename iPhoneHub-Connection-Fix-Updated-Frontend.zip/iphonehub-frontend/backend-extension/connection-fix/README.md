# iPhoneHub network / CORS troubleshooting and backend patch

This directory contains **one replacement file** for your existing backend:
`server.js` -> `backend/src/server.js` in
https://github.com/jonahardiangca202400886-web/iPhone-E-Commerce-Application.
Do **not** copy it to the React project's `src` directory.

## 1. First establish whether the backend is running

Open https://iphone-e-commerce-application.onrender.com/api/v1/health in a normal browser tab.
Expected HTTP 200:
`{"success":true,"data":{"status":"iPhoneHub API is running"}}`

- Browser `ERR_NAME_NOT_RESOLVED`, connection refused, or timeout: **not a CORS problem**. CORS does not apply to top-level page navigation. Confirm the service URL and its status in the Render dashboard, deployment events and logs.
- JSON 404: wrong URL, outdated deployed revision, or an API path mismatch.
- HTTP 200 JSON in a tab but frontend fetch fails: check browser DevTools Network/Console for a CORS error, blocked preflight, or different base URL.
- HTTP 500 from `/products` but 200 from `/health`: app is running; check Supabase connection/schema/keys in backend Render logs. Do not place secret keys in Vite.

## 2. Render backend settings

This repository has its actual backend `package.json` inside `backend/`.
Use **Render Web Service** settings:

- Repository: `jonahardiangca202400886-web/iPhone-E-Commerce-Application`
- **Root Directory:** `backend`
- **Build Command:** `npm install` (or `npm ci` if that directory has an up-to-date lockfile)
- **Start Command:** `npm start` (runs `node src/server.js`)
- Required backend environment names (get values from your own Supabase project):
  - `SUPABASE_URL`
  - `SUPABASE_SECRET_KEY`
  - `SUPABASE_PUBLISHABLE_KEY`
  - `FRONTEND_ORIGINS`

The server imports Supabase configuration when starting, which throws an error if any of the first three settings are missing.
Render injects `PORT`; you do not need to set it manually. The supplied server binds to `0.0.0.0`.

## 3. Allow localhost and production simultaneously

Set the following **on the BACKEND Render Web Service > Environment**:

```env
FRONTEND_ORIGINS=http://localhost:5173,http://127.0.0.1:5173,https://YOUR-FRONTEND-STATIC-SITE.onrender.com
```

Replace `YOUR-FRONTEND-STATIC-SITE` with the real URL. No spaces, no `/` at the end, no API paths. Other local ports (like `5174`) need their own explicit origin. You can retain the older `FRONTEND_ORIGIN` variable; it is also respected.

Replace the backend's `src/server.js` with the supplied `server.js` only after backing up your current version. Commit, push, and **redeploy the backend**. Setting `FRONTEND_ORIGINS` without applying this patch to original source has no effect; original source reads only `FRONTEND_ORIGIN`.

## 4. Frontend setup

Inside `iphonehub-frontend` create `.env`:

```env
VITE_API_BASE_URL=https://iphone-e-commerce-application.onrender.com
```

Use the **backend base URL only** (do not append `/api/v1`), then restart `npm run dev`.
For a deployed Render static frontend, configure the same Vite environment variable in its own dashboard and **rebuild** the site, because Vite embeds it at build time.

## 5. Test preflight and API response

Windows PowerShell:

```powershell
Invoke-RestMethod 'https://iphone-e-commerce-application.onrender.com/api/v1/health'
Invoke-RestMethod 'https://iphone-e-commerce-application.onrender.com/api/v1/products?page=1&limit=4'

curl.exe -i -X OPTIONS 'https://iphone-e-commerce-application.onrender.com/api/v1/auth/login' -H 'Origin: http://localhost:5173' -H 'Access-Control-Request-Method: POST' -H 'Access-Control-Request-Headers: content-type'
```

The last response should include `Access-Control-Allow-Origin: http://localhost:5173`. A direct PowerShell request will **not** itself diagnose CORS (it bypasses browser CORS enforcement). In Chrome DevTools > Network, inspect the failing request and any OPTIONS preflight.

## 6. No fake fixes

This patch only fixes CORS configuration and network error UX. It cannot restart a failed Render service, repair absent Supabase settings, or implement missing e-commerce endpoints. The deployed Render URL could not be reached from the development environment used to assemble this ZIP, so **live availability is not verified**.
