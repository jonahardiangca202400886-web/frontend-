// Replace BACKEND/src/server.js with this file, then redeploy the backend on Render.
// No new database tables or frontend secrets are required by this change.
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import productsRouter from './routes/products.js';
import adminRouter from './routes/admin.js';
import tradeInsRouter from './routes/tradeins.js';
import assistantRouter from './routes/assistant.js';
import authRouter from './routes/auth.js';

const app = express();
app.use(helmet());

// Keep the previous FRONTEND_ORIGIN setting working, but allow several URLs.
// Example: FRONTEND_ORIGINS=http://localhost:5173,https://iphonehub-frontend.onrender.com
const allowedOrigins = new Set(
  [
    'http://localhost:5173',
    'http://127.0.0.1:5173',
    process.env.FRONTEND_ORIGIN || '',
    ...(process.env.FRONTEND_ORIGINS || '').split(',')
  ].map(s => s.trim().replace(/\/+$/, '')).filter(Boolean)
);

app.use(cors({
  origin(origin, callback) {
    // Non-browser clients (curl / Postman / Render health checks) send no Origin.
    if (!origin || allowedOrigins.has(origin)) return callback(null, true);
    console.warn(`CORS denied origin: ${origin}`);
    return callback(null, false);
  },
  credentials: true,
  methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'Accept']
}));

app.use(express.json({ limit: '20kb' }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 200 }));

app.get('/api/v1/health', (_req, res) => {
  res.json({ success: true, data: { status: 'iPhoneHub API is running' } });
});

app.use('/api/v1/products', productsRouter);
app.use('/api/v1/admin', adminRouter);
app.use('/api/v1/trade-ins', tradeInsRouter);
app.use('/api/v1/ai', assistantRouter);
app.use('/api/v1/auth', authRouter);

app.use((_req, res) => res.status(404).json({
  success: false, error: { code: 'NOT_FOUND', message: 'API endpoint not found.' }
}));
app.use((err, _req, res, _next) => {
  console.error('API error:', err.message);
  res.status(500).json({
    success: false, error: { code: 'INTERNAL_ERROR', message: 'An unexpected server error occurred.' }
  });
});

const port = process.env.PORT || 5000;
// Bind to 0.0.0.0 so Render can reach the HTTP server.
app.listen(port, '0.0.0.0', () => console.log(`iPhoneHub API running on port ${port}`));
