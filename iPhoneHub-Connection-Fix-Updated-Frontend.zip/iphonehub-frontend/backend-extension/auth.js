// OPTIONAL DROP-IN REPLACEMENT FOR backend/src/routes/auth.js
// Keeps existing register/login routes, adds verified identity, token refresh, logout.
// Requires only existing dependencies: @supabase/supabase-js and middleware/auth.js.
// DO NOT deploy this by placing it in the frontend. Copy it to the existing BACKEND repo.
import { Router } from 'express';
import { createClient } from '@supabase/supabase-js';
import { db } from '../config/supabase.js';
import { requireAuth } from '../middleware/auth.js';
const router = Router();
function newUserAuthClient() {
  return createClient(process.env.SUPABASE_URL, process.env.SUPABASE_PUBLISHABLE_KEY, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false }
  });
}
function publicUser(user) {
  return user ? { id: user.id, email: user.email, user_metadata: { full_name: user.user_metadata?.full_name || '' } } : null;
}
router.post('/register', async (req, res) => {
  try {
    const { full_name, email, password } = req.body || {};
    if (!full_name?.trim() || !email?.trim() || typeof password !== 'string' || password.length < 8) {
      return res.status(422).json({ success: false, message: 'Name, email and password (at least 8 characters) are required.' });
    }
    const { data, error } = await newUserAuthClient().auth.signUp({ email: email.trim(), password, options: { data: { full_name: full_name.trim() } } });
    if (error) return res.status(400).json({ success: false, message: error.message });
    return res.status(201).json({ success: true, message: 'Registration successful. Check email if verification is required.', data: { user: publicUser(data.user), session: data.session } });
  } catch (e) { return res.status(500).json({ success: false, message: 'Registration unavailable.' }); }
});
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) return res.status(422).json({ success: false, message: 'Email and password are required.' });
    const { data, error } = await newUserAuthClient().auth.signInWithPassword({ email, password });
    if (error || !data?.session) return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    return res.json({ success: true, message: 'Login successful.', data: { user: publicUser(data.user), access_token: data.session.access_token, refresh_token: data.session.refresh_token, expires_at: data.session.expires_at } });
  } catch { return res.status(401).json({ success: false, message: 'Login failed.' }); }
});
router.get('/me', requireAuth, async (req, res) => {
  const { data, error } = await db.from('profiles').select('full_name,role').eq('id', req.user.id).single();
  if (error || !data) return res.status(404).json({ success: false, error: { code: 'PROFILE_NOT_FOUND', message: 'Account profile is not available.' } });
  return res.json({ success: true, data: { id: req.user.id, email: req.user.email, full_name: data.full_name, role: data.role } });
});
router.post('/refresh', async (req, res) => {
  const refresh_token = req.body?.refresh_token;
  if (!refresh_token || typeof refresh_token !== 'string') return res.status(422).json({ success: false, message: 'Refresh token is required.' });
  const { data, error } = await newUserAuthClient().auth.refreshSession({ refresh_token });
  if (error || !data?.session) return res.status(401).json({ success: false, message: 'Session expired. Please sign in again.' });
  return res.json({ success: true, data: { access_token: data.session.access_token, refresh_token: data.session.refresh_token, expires_at: data.session.expires_at, user: publicUser(data.user) } });
});
router.post('/logout', requireAuth, async (req, res) => {
  try {
    const refresh_token = req.body?.refresh_token;
    if (!refresh_token) return res.status(422).json({ success: false, message: 'Refresh token is required.' });
    const client = newUserAuthClient();
    const { data, error } = await client.auth.setSession({ access_token: req.headers.authorization.slice(7), refresh_token });
    if (error || data?.user?.id !== req.user.id) return res.status(401).json({ success: false, message: 'Session mismatch or invalid token.' });
    const { error: signOutError } = await client.auth.signOut({ scope: 'local' });
    if (signOutError) return res.status(500).json({ success: false, message: 'Unable to revoke session.' });
    return res.json({ success: true, message: 'Session signed out.' });
  } catch { return res.status(500).json({ success: false, message: 'Unable to sign out.' }); }
});
export default router;
