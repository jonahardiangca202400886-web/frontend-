# iPhoneHub — Premium React + Vite storefront

> **Connection troubleshooting update:** If you see “Cannot reach the iPhoneHub server”, read [`CONNECTION_FIX_START_HERE.md`](CONNECTION_FIX_START_HERE.md). A multi-origin CORS backend patch is provided at [`backend-extension/connection-fix/server.js`](backend-extension/connection-fix/server.js). The patch must be applied to your **separate backend repository**, committed and redeployed; it is not automatically installed by downloading this frontend.


A responsive iPhone-only frontend built to match the **actual public routes** of your existing Express + Supabase backend. Clean original iPhoneHub design; React Router; full catalog browsing; authenticated shopping advisor with catalog fallback; authenticated trade-in submission/history; protected admin product tools. Local shopping bag and a clearly labelled checkout **preview**, not fake orders or payments.

## 1. Requirements

- Node.js 20.19+ (Node.js 22 LTS recommended), npm, VS Code
- Existing backend: https://iphone-e-commerce-application.onrender.com
- An existing Supabase project already wired to your backend

## 2. Run in VS Code

Extract this ZIP, open the **iphonehub-frontend** folder, and in its VS Code terminal run:

```bash
npm install
```

Copy `.env.example` to `.env` (on Windows PowerShell: `Copy-Item .env.example .env`):

```env
VITE_API_BASE_URL=https://iphone-e-commerce-application.onrender.com
```

Then:

```bash
npm run dev
```

Open `http://localhost:5173`.

Build before deployment:

```bash
npm run check
npm test
npm run build
npm run preview
```

`npm run check` checks JSX/JavaScript syntax. The production build output is the `dist` folder. It intentionally does **not** contain credentials.

## 3. One-time configuration on your existing Express backend

In backend Render environment, set:

```env
FRONTEND_ORIGIN=http://localhost:5173
```

For **deployed frontend**, change `FRONTEND_ORIGIN` to the **exact deployed frontend URL** (example: `https://YOUR-IPHONEHUB-FRONTEND.onrender.com`). The current backend allows only one origin. If you need localhost **and** production simultaneously, modify the backend's CORS configuration to allowlist both, not `*`.

Do **not** put Supabase secret keys, Gemini API keys, or Maya keys in `.env` of your Vite frontend. `VITE_` values are public after build.

### Admin setup — important

Original backend DOES enforce `requireAdmin` on writes, but it has no read endpoint to tell the frontend whether a user is an admin. **This frontend intentionally does not grant admin access based on a hardcoded email or browser-only role.**

To enable the admin dashboard, read `backend-extension/README.md` and optionally copy `backend-extension/auth.js` over the original `backend/src/routes/auth.js` in your BACKEND repository, commit and redeploy. That adds verified `/api/v1/auth/me`, refresh and logout. Admin role still comes from `public.profiles.role`. To assign an existing user administrator privileges, use the SQL editor with a known valid `auth.users.id` and appropriate authorization:

```sql
update public.profiles set role = 'admin' where id = 'YOUR_AUTH_USER_UUID';
```

Never expose an admin-role selector during registration.

## 4. Pages

| Route | Functionality |
|---|---|
| `/` | Premium homepage, current featured catalog records, brand/editorial sections |
| `/shop` | API-based search, local model type filters, sorting and pagination |
| `/products/:id` | Product details, available variants, stock, bag actions |
| `/register`, `/login` | Real backend Supabase registration/sign-in via Express |
| `/cart` | Local persisted bag, quantity update, remove, estimated subtotal |
| `/checkout` | Delivery form, live revalidation of prices/stock, **no order/payment submission** |
| `/payment/pending`, `/payment/success`, `/payment/failed`, `/payment/cancelled` | **Unverified** payment callback screens; cannot confirm outcome |
| `/orders` | Honest missing-backend status; no fake order records |
| `/assistant` | Real Gemini endpoint + fallback catalog-based suggestions |
| `/trade-in` | Actual customer trade-in request creation and history |
| `/admin` | Verified admin dashboard: catalog stats, backend availability |
| `/admin/products` | Create/edit/archive active products; adjust existing variant stock |
| `/admin/orders`, `/admin/customers`, `/admin/coupons` | Honest backend-availability explanations |

All pages are responsive from desktop to compact mobile. The phone used for hero artwork is a CSS illustration; catalog cards show the URL stored in `products.image_url` or a neutral local phone placeholder. There are **no invented sample product prices** in the frontend.

## 5. Authentication and carts

The backend returns a Supabase access token on login. The frontend holds it in **sessionStorage**, removes it on logout, and revalidates role if `/auth/me` is available. Existing unpatched API lacks refresh tokens, so the user needs to sign in again when the token expires. Optional backend patch adds refresh/logout support. For a financial production application, migrate tokens to secure server-managed cookies.

The cart uses **localStorage** for convenience, scoped to this browser/device rather than to the backend account. Local price snapshots are **not** authoritative. The checkout page re-fetches `GET /products/:id` and uses live variant prices for an informational comparison. The original backend has no cart/order/payment HTTP routes; real checkout is **not enabled**.

## 6. Publish frontend on Render

1. Push only the frontend folder to a new GitHub repository (keep it separate from your existing backend).
2. Render → New → **Static Site** → Connect your frontend repository.
3. Build command: `npm install && npm run build`.
4. Publish directory: `dist`.
5. Environment: `VITE_API_BASE_URL=https://iphone-e-commerce-application.onrender.com`.
6. Add Render rewrite: Source `/*`, Destination `/index.html`, Action `Rewrite` so React Router paths load directly.
7. Set the backend Render `FRONTEND_ORIGIN` to the deployed static-site address, then redeploy backend.
8. Test login, `/shop`, detail and trade-in routes on both desktop and mobile.

## 7. API documentation and known gaps

- `API_INVENTORY.md` — inspected endpoints including exact request bodies, query parameters, authorization, success/error envelopes, and optional auth patch routes.
- `BACKEND_GAPS.md` — missing APIs to add before enabling order placement, payment, coupons, complete admin workflows.
- `backend-extension/README.md` — optional auth patch setup, caution and smoke checks.
- `TESTING.md` — manual test matrix and deployment verification checklist.

## 8. What was verified for this ZIP

- Read original public GitHub repository source (routes, middleware, config and database schema).
- Parsed every project JavaScript/JSX source file for syntax errors.
- Live Render endpoint calls were attempted, but the host was inaccessible from this environment; **no live registration, checkout, payments or full end-to-end claims are made**.
- `npm install` / `npm run build` require fetching dependencies, which was not possible within this isolated environment. Run these commands on your machine and review the first network responses before production deployment.

**Next implementation milestone:** Deploy the optional auth patch and add backend cart/order/payment services, then replace the checkout preview with a real order flow.
