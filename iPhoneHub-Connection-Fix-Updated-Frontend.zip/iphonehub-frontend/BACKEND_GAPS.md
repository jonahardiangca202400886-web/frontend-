# Missing backend endpoints and implementation priorities

**Do not add these routes to the frontend API client until actually implemented on the backend.** A matching Supabase table does not make a REST route available. Endpoints below are **suggested contracts, NOT existing routes**. The frontend never sends requests to them.

## P0 — Required for genuine checkout and purchase

1. **Verified authenticated cart**: propose `GET /api/v1/cart`, `POST /api/v1/cart/items`, `PATCH /api/v1/cart/items/:id`, `DELETE /api/v1/cart/items/:id`. Bind to user from Bearer token, not client-provided user_id. Use variant IDs and validate stock. The current local bag is not an account cart.
2. **Checkout calculation and order creation**: propose `POST /api/v1/checkout/quote` and `POST /api/v1/orders`. On server: re-read product/variant prices and availability, validate customer address and coupon, compute subtotal/discount/shipping/tax, lock/reserve stock atomically, use `idempotency_key` to avoid duplicate orders, persist `orders` + `order_items`. **Never trust browser totals.**
3. **Customer order reads**: propose `GET /api/v1/orders/mine` and `GET /api/v1/orders/:id`. Enforce `customer_id === authenticated_user.id` for every read and ensure details include item snapshots and payment/order statuses.
4. **Maya sandbox integration**: propose `POST /api/v1/payments/maya/checkout`, `GET /api/v1/payments/:orderId/status`, and a server-to-server webhook. Use real Maya credentials server-side, verify signatures / authenticate event source according to Maya's current developer requirements, store provider event IDs idempotently, reconcile payments to orders. Never mark orders paid based on a frontend redirect. (The repository README discusses a **PayMongo** future integration, not working Maya endpoints; choose your provider explicitly before implementing.)
5. **Coupons**: propose a server-side code validation route and admin coupon endpoints. Apply fixed/percent discounts with minimum spend, expiry, usage limits, and atomic redemption updates.

## P1 — Required for comprehensive admin operations

6. `GET /api/v1/admin/products` including `is_active=false` (and pagination); currently admins can see only the public active list and cannot re-enable an archived product from the UI.
7. `DELETE /api/v1/admin/products/:id` with a carefully designed archive/hard-delete policy and foreign-key rules; currently **archive** is supported, not hard delete.
8. `POST /api/v1/admin/products/:id/variants`, plus PATCH / deactivate variant endpoints; the current API can adjust existing variant stock but cannot create variants. Product detail is read-only for variant configurations.
9. `GET /api/v1/admin/orders`, `GET /api/v1/admin/orders/:id`, `PATCH /api/v1/admin/orders/:id/status`, protected with `requireAuth,requireAdmin` and validated state transitions.
10. `GET /api/v1/admin/customers` and restricted customer details, with least-privilege disclosure and privacy auditing.
11. Admin coupon CRUD and analytics endpoints backed by paid orders and audit logs; do not derive sales revenue from total catalog list prices.
12. `GET /api/v1/admin/trade-ins`, review / quote endpoints if the team needs staff-side trade-in processing.

## P0 — Authentication security gap (optional patch included)

The original backend lacks `GET /api/v1/auth/me`, refresh and logout, and login does not supply refresh credentials. `backend-extension/auth.js` provides these three routes and extends login. Until deployed, the frontend **blocks the admin workspace** because an admin role cannot be verified. The frontend still uses the existing `requireAdmin` on server writes.

**Production hardening:** Consider HttpOnly Secure SameSite session cookies (plus CSRF protection), centralized session lifecycle, rate limiting on auth, schema validation, logging/redaction, audit trails, timeout handling and CORS allowlisting. The provided patch retains Bearer tokens for compatibility and keeps them in sessionStorage rather than localStorage. The JWT access token is short-lived and, if signed out only locally, may be valid until its expiry.

## Data schema notes

- Existing `products.model` is unique. An attempted duplicate iPhone model will fail backend insert even if its name is different.
- Existing `product_variants` requires storage, color, condition, price and stock. The seed products may have zero variants; no checkout should proceed without a valid variant.
- Database `orders` already has subtotal, discount, shipping_fee, total and idempotency_key but no Express write controller. Use a database transaction/RPC for consistent stock/order creation.
- Never expose `inventory_units.imei_or_serial` through public catalog responses.

## Implementation order

Deploy the optional auth patch → add variant management and an admin product listing → implement server carts and checkout with transaction-safe validation → add Maya sandbox checkout, verification, and webhook processing → finish customer/admin orders, coupons, and real analytics → add integration tests → enable corresponding frontend features.
