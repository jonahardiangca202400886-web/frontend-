# iPhoneHub API integration inventory

**Inspection source:** Public `main` branch at https://github.com/jonahardiangca202400886-web/iPhone-E-Commerce-Application, inspected 2026-11-23. Inspected: `backend/src/server.js`, all five route modules (`products.js`, `admin.js`, `tradeins.js`, `assistant.js`, `auth.js`), `config/supabase.js`, `middleware/auth.js`, `backend/package.json`, and `database/schema.sql`.

**Base:** `https://iphone-e-commerce-application.onrender.com/api/v1` (configured by `VITE_API_BASE_URL`, which intentionally excludes `/api/v1`).

**Important verification boundary:** Source code was inspected. Direct access to the deployed Render host returned an inaccessible/network result from the available environment, so real network responses could **not** be confirmed. Schema details below reflect source only, not deployment state. Backend may be different if Render is running an older commit.

## Original routes confirmed in source

| Method | Exact path | Request body / parameters | Auth | Response on success | Error |
|---|---|---|---|---|---|
| GET | `/api/v1/health` | none | Public | `{success:true,data:{status:'iPhoneHub API is running'}}` | 404 for unknown paths |
| GET | `/api/v1/products` | query: `search` (name/model substring), `page` (>=1, default 1), `limit` (1–50, default 12) | Public | `{success:true,data:[{id,name,model,description,base_price,image_url,is_active,created_at}],meta:{page,limit,total,pages}}` | 500 `{success:false,error:{code:'PRODUCT_LIST_FAILED',message}}` |
| GET | `/api/v1/products/:id` | `id` route parameter | Public | `{success:true,data:{...product,product_variants:[{id,product_id,storage,color,condition,price,stock,...}]}}` | 404 `{success:false,error:{code:'PRODUCT_NOT_FOUND',message}}` |
| POST | `/api/v1/auth/register` | `{full_name,email,password}` (password >=8 characters) | Public | 201 `{success:true,message,data:{user,session}}` (`session` may be null if email confirmation needed) | 400/422 `{success:false,message}` |
| POST | `/api/v1/auth/login` | `{email,password}` | Public | `{success:true,message,data:{user,access_token}}` | 401/422 `{success:false,message}` |
| POST | `/api/v1/ai` | `{message:string}` (1–500 chars) | User Bearer token | `{success:true,data:{explanation,products:[{id,name,model,description,base_price}]}}` | 422/503/500 `{success:false,message}` |
| POST | `/api/v1/ai/recommend` | Same as `/api/v1/ai` | User Bearer token | Same as above | Same as above |
| POST | `/api/v1/trade-ins` | `{iphone_model,storage,condition,battery_health,notes?}` (model must contain iPhone; condition excellent/good/fair/poor; battery health integer 1–100) | User Bearer token | 201 `{success:true,data:{...trade_in_requests row}}` | 422/400 `{success:false,error:{code,message}}` |
| GET | `/api/v1/trade-ins/mine` | none | User Bearer token | `{success:true,data:[...customer's trade_in_requests rows]}` | 500 `{success:false,error:{code,message}}` |
| POST | `/api/v1/admin/products` | `{name,model,description?,base_price,image_url?}` | Admin Bearer token + profile `role=admin` | 201 `{success:true,data:{...product row}}` | 422/400 `{success:false,error:{code,message}}` |
| PATCH | `/api/v1/admin/products/:id` | Whitelisted properties: `name,model,description,base_price,image_url,is_active` | Admin Bearer token + profile `role=admin` | `{success:true,data:{...updated product row}}` | 422/404 `{success:false,error:{code,message}}` |
| POST | `/api/v1/admin/variants/:id/stock` | `{quantity: nonzero integer,reason: nonempty string}`; positive or negative changes | Admin Bearer token + profile `role=admin` | `{success:true,data:{variant_id,previous_stock,new_stock}}` | 422/409 `{success:false,error:{code,message}}` |

### Auth middleware and error conventions

- Protected endpoints check `Authorization: Bearer ACCESS_TOKEN`; token is validated via `authClient.auth.getUser(token)` in `middleware/auth.js`.
- Admin middleware then loads the `profiles` row for the authenticated UUID and requires `role === 'admin'`; security is enforced in Express rather than inferred from the UI.
- Failed authentication uses HTTP 401 `{success:false,error:{code,message}}`; forbidden admin operations use HTTP 403 of the same shape.
- Most route failures return nested `error.message`; auth and AI instead return top-level `message`. The centralized frontend client supports both.
- Auth login response in **original** code provides access token only: **no refresh token** and no verified role. The optional patch adds the required functions.
- Original `server.js` configures CORS with **one** `FRONTEND_ORIGIN`, defaults to `http://localhost:5173`.
- Original `server.js` applies a global request rate limit of 200 requests / 15 minutes.

### Database relationships observed

`auth.users` → `profiles` (role), `products` → `product_variants` (stock, price per configuration) → `inventory_units` (private device identifiers), `auth.users` → `carts` → `cart_items` (by variant), `auth.users` → `orders` → `order_items`, `coupons` → `orders`, `auth.users` → `trade_in_requests`, `orders` → `payment_events` / `order_status_history`, `product_variants` → `stock_movements`.

**Database tables existing does NOT mean HTTP routes exist.** The frontend calls none of these tables directly. Admin inventory adjustment uses the backend RPC `adjust_variant_stock`, which records an audit row.

## OPTIONAL ROUTES provided as separate backend patch

Not part of original audited routes; see `backend-extension/auth.js` and `backend-extension/README.md`.

| Method | Path | Request | Response |
|---|---|---|---|
| GET | `/api/v1/auth/me` | Bearer access token | `{success:true,data:{id,email,full_name,role}}` |
| POST | `/api/v1/auth/refresh` | `{refresh_token}` | `{success:true,data:{access_token,refresh_token,expires_at,user}}` |
| POST | `/api/v1/auth/logout` | Bearer access token + `{refresh_token}` | `{success:true,message}` |

Modified login also returns `refresh_token` and `expires_at` in `data`. This supports role verification, token refresh and session logout; **it requires you to deploy the optional patch to your backend**.

## Frontend behavior table

| Feature | What the frontend does with original backend |
|---|---|
| Home/catalog/product details/search | Live REST data, search & pagination, client-side categorization/sorting |
| Login and registration | Real original endpoints; session token held in sessionStorage, cleared on logout / expiry |
| Protected AI advisor | Real `POST /ai`; if AI fails, shows plainly labelled fallback results from the live catalog |
| Trade-ins | Real submit/list endpoints, customer-scoped server authorization |
| Product create/edit | Real protected admin requests; UI requires `/auth/me` patch first for **verified** admin entry |
| Product archive | Uses PATCH `{is_active:false}`; original public list cannot show archived rows |
| Stock adjustment | Real protected `POST /admin/variants/:id/stock` for existing variants |
| Bag/cart | Local-only; item prices are clearly estimates and are not used for final charges |
| Checkout | Address validation and live price/stock reconciliation preview; no order/payment request sent |
| My orders | Explains missing routes rather than fabricating history |
| Payment return | Labels any return URL as **unverified**; never claims payment was made |
| Admin orders/customers/coupons/revenue | Explicitly unavailable until protected routes exist |
