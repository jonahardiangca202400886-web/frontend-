import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import * as authApi from '../api/auth';
const KEY = 'iphonehub:session:v1';
const AuthContext = createContext(null);
const readSession = () => { try { return JSON.parse(sessionStorage.getItem(KEY) || 'null'); } catch { return null; } };
export function AuthProvider({ children }) {
  const [session, setSession] = useState(readSession);
  const [role, setRole] = useState('checking');
  const [checking, setChecking] = useState(true);
  const saveSession = useCallback((next) => { setSession(next); if (next) sessionStorage.setItem(KEY, JSON.stringify(next)); else sessionStorage.removeItem(KEY); }, []);
  const verifyRole = useCallback(async (token) => {
    if (!token) { setRole('guest'); return; }
    try {
      const payload = await authApi.me(token);
      setRole(payload.data?.role === 'admin' ? 'admin' : 'customer');
    } catch (error) {
      if (error.status === 401) { saveSession(null); setRole('guest'); }
      else setRole('unverified'); // /auth/me does not exist until optional backend patch deployed
    }
  }, [saveSession]);
  useEffect(() => { let active = true; (async () => { if (session?.access_token) await verifyRole(session.access_token); else setRole('guest'); if (active) setChecking(false); })(); return () => { active = false; }; }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const signIn = async (email, password) => {
    const payload = await authApi.login({ email, password });
    const data = payload.data || {};
    if (!data.access_token) throw new Error('Login succeeded, but the API did not return an access token.');
    const next = { access_token: data.access_token, refresh_token: data.refresh_token || null, user: data.user, expires_at: data.expires_at || null };
    saveSession(next); await verifyRole(next.access_token);
    return next;
  };
  const signUp = async (values) => {
    const payload = await authApi.register(values);
    // Supabase email confirmation may be required. No fake session if none is returned.
    const nextSession = payload.data?.session;
    if (nextSession?.access_token) {
      const next = { access_token: nextSession.access_token, refresh_token: nextSession.refresh_token || null, expires_at: nextSession.expires_at || null, user: payload.data?.user };
      saveSession(next); await verifyRole(next.access_token);
    }
    return payload;
  };
  const signOut = async () => {
    const prev = session;
    saveSession(null); setRole('guest');
    if (prev?.refresh_token) { try { await authApi.logout(prev.access_token, prev.refresh_token); } catch { /* local sign-out still clears this browser; server revocation needs backend patch */ } }
  };
  const authorized = async (operation) => {
    if (!session?.access_token) throw new Error('Please sign in to continue.');
    try { return await operation(session.access_token); }
    catch (error) {
      if (error.status !== 401) throw error;
      if (session.refresh_token) {
        try {
          const res = await authApi.refresh(session.refresh_token);
          const d = res.data || {};
          if (d.access_token) {
            const next = { ...session, ...d, access_token: d.access_token };
            saveSession(next); await verifyRole(next.access_token);
            return await operation(next.access_token);
          }
        } catch { /* patch unavailable, refresh expired or revoked */ }
      }
      saveSession(null); setRole('guest');
      throw new Error('Your session has expired. Please sign in again.');
    }
  };
  return <AuthContext.Provider value={{ user: session?.user || null, token: session?.access_token || null, isAuthenticated: !!session?.access_token, role, checking, signIn, signUp, signOut, authorized, verifyRole: () => verifyRole(session?.access_token) }}>{children}</AuthContext.Provider>;
}
export const useAuth = () => useContext(AuthContext);
