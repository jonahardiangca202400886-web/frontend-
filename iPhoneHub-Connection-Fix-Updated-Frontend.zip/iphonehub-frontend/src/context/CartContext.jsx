import { createContext, useContext, useMemo, useState } from 'react';
import { getPrice } from '../utils/format';
const KEY = 'iphonehub:local-cart:v1';
const CartContext = createContext(null);
function read() { try { const a = JSON.parse(localStorage.getItem(KEY)); return Array.isArray(a) ? a : []; } catch { return []; } }
export function CartProvider({ children }) {
  const [items, setItems] = useState(read);
  const update = (callback) => setItems(old => { const next = callback(old); localStorage.setItem(KEY, JSON.stringify(next)); return next; });
  const add = (product, variant, quantity = 1) => {
    const key = `${product.id}:${variant?.id || 'base'}`;
    const max = variant ? Number(variant.stock) : 99;
    const qty = Math.max(1, Math.floor(Number(quantity) || 1));
    update(old => {
      const existing = old.find(i => i.key === key);
      const newQty = Math.min(max, (existing?.quantity || 0) + qty);
      const item = { key, productId: product.id, variantId: variant?.id || null, name: product.name, model: product.model, image_url: product.image_url, storage: variant?.storage || '', color: variant?.color || '', condition: variant?.condition || '', quantity: newQty, stockSnapshot: variant?.stock ?? null, priceSnapshot: getPrice(product, variant) };
      return existing ? old.map(i => i.key === key ? item : i) : [...old, item];
    });
  };
  const remove = key => update(old => old.filter(i => i.key !== key));
  const quantity = (key, value) => update(old => old.map(i => i.key === key ? { ...i, quantity: Math.max(1, Math.min(Number(i.stockSnapshot ?? 99), Math.floor(Number(value) || 1))) } : i));
  const clear = () => update(() => []);
  const count = useMemo(() => items.reduce((t, x) => t + x.quantity, 0), [items]);
  const estimate = useMemo(() => items.reduce((t, x) => t + x.priceSnapshot * x.quantity, 0), [items]);
  return <CartContext.Provider value={{ items, count, estimate, add, remove, quantity, clear }}>{children}</CartContext.Provider>;
}
export const useCart = () => useContext(CartContext);
