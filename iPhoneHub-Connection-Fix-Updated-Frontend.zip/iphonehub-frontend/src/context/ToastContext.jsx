import { createContext, useCallback, useContext, useState } from 'react';
import { CheckCircle2, AlertTriangle, Info, X } from 'lucide-react';
const ToastContext = createContext(null);
export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const dismiss = useCallback(id => setToasts(list => list.filter(item => item.id !== id)), []);
  const notify = useCallback((message, type='info') => {
    const id = `${Date.now()}-${Math.random()}`;
    setToasts(list => [...list.slice(-3), { id, message, type }]);
    return id;
  }, []);
  return <ToastContext.Provider value={{ notify, dismiss }}>{children}<div className="toast-stack" aria-live="polite">{toasts.map(t => <div className={`toast toast-${t.type}`} key={t.id}>{t.type === 'success' ? <CheckCircle2 size={21}/> : t.type === 'error' ? <AlertTriangle size={21}/> : <Info size={21}/>}<span>{t.message}</span><button className="icon-button" onClick={() => dismiss(t.id)} aria-label="Dismiss notification"><X size={18}/></button></div>)}</div></ToastContext.Provider>;
}
export const useToast = () => useContext(ToastContext);
