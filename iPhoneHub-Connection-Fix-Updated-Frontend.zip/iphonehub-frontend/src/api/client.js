// Vite values are public build-time configuration; never place secrets in this URL.
// Accept either a base URL or a URL accidentally ending with /api/v1.
export const API_BASE = (import.meta.env.VITE_API_BASE_URL || 'https://iphone-e-commerce-application.onrender.com')
  .trim().replace(/\/+$/, '').replace(/\/api\/v1$/i, '');
export class ApiError extends Error {
  constructor(message, status, code) { super(message); this.name = 'ApiError'; this.status = status; this.code = code; }
}
export async function request(path, { method = 'GET', body, token, signal, headers = {} } = {}) {
  let response;
  try {
    response = await fetch(`${API_BASE}/api/v1${path}`, {
      method, signal,
      headers: { 'Accept': 'application/json', ...(body === undefined ? {} : { 'Content-Type': 'application/json' }), ...(token ? { Authorization: `Bearer ${token}` } : {}), ...headers },
      ...(body === undefined ? {} : { body: JSON.stringify(body) })
    });
  } catch (error) {
    if (error?.name === 'AbortError') throw error;
    throw new ApiError(
      `Network request could not complete. Open ${API_BASE}/api/v1/health in a new tab. ` +
      'If that page does not load, check the backend service on Render; if it loads but this page fails, check the browser Console for a CORS error and confirm FRONTEND_ORIGINS.',
      0, 'NETWORK_ERROR'
    );
  }
  const contentType = response.headers.get('content-type') || '';
  const payload = contentType.includes('application/json') ? await response.json().catch(() => null) : null;
  if (!response.ok || payload?.success === false) {
    throw new ApiError(payload?.error?.message || payload?.message || `Request failed (${response.status})`, response.status, payload?.error?.code || 'API_ERROR');
  }
  if (!payload) throw new ApiError('Unexpected response from the server.', response.status, 'INVALID_RESPONSE');
  return payload;
}
