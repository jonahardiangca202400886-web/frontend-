import { request } from './client';
export const createProduct = (body, token) => request('/admin/products', { method: 'POST', body, token });
export const updateProduct = (id, body, token) => request(`/admin/products/${encodeURIComponent(id)}`, { method: 'PATCH', body, token });
export const adjustStock = (id, body, token) => request(`/admin/variants/${encodeURIComponent(id)}/stock`, { method: 'POST', body, token });
