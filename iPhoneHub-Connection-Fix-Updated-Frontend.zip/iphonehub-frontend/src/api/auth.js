import { request } from './client';
export const login = (body) => request('/auth/login', { method: 'POST', body });
export const register = (body) => request('/auth/register', { method: 'POST', body });
// These three routes are in backend-extension/auth.js; not in original deployed starter.
export const me = (token) => request('/auth/me', { token });
export const refresh = (refresh_token) => request('/auth/refresh', { method: 'POST', body: { refresh_token } });
export const logout = (token, refresh_token) => request('/auth/logout', { method: 'POST', token, body: { refresh_token } });
