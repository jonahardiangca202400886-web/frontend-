// Audited against the actual backend routes, not conjectural API endpoints.
export const capabilities = Object.freeze({
  catalog: true, productDetails: true, register: true, login: true,
  tradeIns: true, ai: true, adminProductCreate: true, adminProductEdit: true, adminStock: true,
  serverCart: false, orders: false, checkout: false, coupons: false,
  paymentVerification: false, adminOrders: false, adminCustomers: false,
  adminCoupons: false, adminProductList: false, variantCreate: false,
  // Requires installing backend-extension/auth.js and deploying it:
  sessionRefresh: false, verifiedRole: false, serverLogout: false
});
