import { request } from './client';
export const recommend = (message, token) => request('/ai', { method: 'POST', body: { message }, token });
