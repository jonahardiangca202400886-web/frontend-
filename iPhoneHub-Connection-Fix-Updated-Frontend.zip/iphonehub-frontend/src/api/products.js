import { request } from './client';
export const listProducts = (params = {}, signal) => request(`/products?${new URLSearchParams(params)}`, { signal });
export const getProduct = (id, signal) => request(`/products/${encodeURIComponent(id)}`, { signal });
export async function listAllProducts(search = '', signal) {
  const result = []; let page = 1; let maxPages = 1;
  do {
    const payload = await listProducts({ search, page, limit: 50 }, signal);
    result.push(...(Array.isArray(payload.data) ? payload.data : []));
    maxPages = Math.min(Number(payload.meta?.pages || 1), 20);
    page++;
  } while (page <= maxPages);
  return { products: result, limited: maxPages >= 20 };
}
