import { request } from './client';
export const createTradeIn = (body, token) => request('/trade-ins', { method: 'POST', body, token });
export const myTradeIns = (token) => request('/trade-ins/mine', { token });
