import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { Layout, AdminLayout } from './components/Layout';
import { ProtectedRoute, AdminRoute } from './components/Guards';
import Home from './pages/Home';
import Catalog from './pages/Catalog';
import ProductDetails from './pages/ProductDetails';
import { Login, Register } from './pages/Authentication';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Orders from './pages/Orders';
import Assistant from './pages/Assistant';
import TradeIn from './pages/TradeIn';
import PaymentStatus from './pages/PaymentStatus';
import { AdminDashboard, AdminProducts, AdminUnavailable } from './pages/Admin';
import NotFound from './pages/NotFound';
function ScrollReset(){const {pathname}=useLocation();useEffect(()=>{window.scrollTo({top:0,behavior:'auto'});},[pathname]);return null;}
export default function App(){return <><ScrollReset/><Routes><Route element={<Layout/>}><Route index element={<Home/>}/><Route path="shop" element={<Catalog/>}/><Route path="products/:id" element={<ProductDetails/>}/><Route path="login" element={<Login/>}/><Route path="register" element={<Register/>}/><Route path="cart" element={<Cart/>}/><Route path="checkout" element={<Checkout/>}/><Route path="payment/:state" element={<PaymentStatus/>}/><Route element={<ProtectedRoute/>}><Route path="orders" element={<Orders/>}/><Route path="trade-in" element={<TradeIn/>}/></Route><Route path="assistant" element={<Assistant/>}/><Route path="*" element={<NotFound/>}/></Route><Route element={<AdminRoute/>}><Route path="admin" element={<AdminLayout/>}><Route index element={<AdminDashboard/>}/><Route path="products" element={<AdminProducts/>}/><Route path=":section" element={<AdminUnavailable/>}/></Route></Route></Routes></>}
