export const peso = (value) => Number.isFinite(Number(value)) ? new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP', maximumFractionDigits: 2 }).format(Number(value)) : 'Price unavailable';
export const dateText = (date) => date ? new Date(date).toLocaleDateString('en-PH', { year: 'numeric', month: 'short', day: 'numeric' }) : '—';
export const getPrice = (product, variant) => Number(variant?.price ?? product?.base_price ?? 0);
export const categoryOf = (product) => /pro/i.test(product.model) ? 'Pro' : /plus/i.test(product.model) ? 'Plus' : /mini/i.test(product.model) ? 'Mini' : 'Standard';
export const cleanUrl = (value) => { try { const url = new URL(value); return ['https:', 'http:'].includes(url.protocol) ? url.href : null; } catch { return null; } };
