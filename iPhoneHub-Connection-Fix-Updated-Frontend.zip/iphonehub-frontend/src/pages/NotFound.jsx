import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
export default function NotFound() {return <div className="container page-block not-found"><span>404</span><h1>This page got away.</h1><p>We couldn't find the page you're looking for.</p><Link className="btn btn-dark" to="/">Back to home <ArrowRight size={17}/></Link></div>}
