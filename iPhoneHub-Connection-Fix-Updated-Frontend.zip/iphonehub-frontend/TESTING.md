# iPhoneHub test checklist

## Build and static checks

```bash
npm install
npm run check
npm test
npm run build
npm run dev
```

Open browser DevTools → Console and Network on every test. No missing chunks, failed imports or broken React Router links should appear. Backend Render cold starts can take time; a network error is shown rather than invented data.

## API inspection smoke checks (Windows PowerShell)

```powershell
Invoke-RestMethod 'https://iphone-e-commerce-application.onrender.com/api/v1/health'
Invoke-RestMethod 'https://iphone-e-commerce-application.onrender.com/api/v1/products?page=1&limit=4'
```

Expected: `{ success: true, ... }` from both after the server is running. If unreachable, verify Render logs, deploy status, credentials and `FRONTEND_ORIGIN`.

## Test matrix

- [ ] Homepage loads catalog products or a useful backend error/empty state.
- [ ] Catalog search finds models; search clearing works; Pro/Plus filters and sorting work; pagination changes displayed items.
- [ ] Product details display live variant price/stock; zero stock disables add button.
- [ ] Missing product image uses neutral illustration, not an invented product photograph.
- [ ] Register with email/full name/password, then follow verification email if enabled; incorrect passwords show backend error.
- [ ] Login with real credentials; password visibility toggle works; fake credentials fail.
- [ ] Reload same tab: session restores when valid; expired token returns to login after a protected API rejects it.
- [ ] Logout clears sessionStorage; protected pages require sign-in.
- [ ] Shopping bag add, remove, increment and decrement persist on reload. Estimates labelled, not authoritative.
- [ ] Checkout preview re-fetches prices and stock, validates delivery fields, and **does not create an order or claim payment**.
- [ ] AI chat with actual account returns catalog-backed products; Gemini outage triggers labelled catalog fallback; retry action works.
- [ ] Trade-in form validates model/condition/battery and saves request; history shows only the signed-in customer's data.
- [ ] On **unpatched** backend, admin page remains blocked due to missing `/auth/me` (expected safety behavior).
- [ ] On **patched** backend, customer receives 403/blocked admin; administrator reaches dashboard and product create/edit.
- [ ] Admin image URL is persisted; product archive removes item from public catalog; stock adjustments change the variant count with recorded audit entry.
- [ ] Admin orders/customers/coupons show backend requirements and do not claim nonexistent data.
- [ ] Payment return URL, e.g. `/payment/success`, displays **unverified** not a fake success banner.
- [ ] Direct navigation to `/shop` and `/products/<real-id>` works after deploying Render SPA rewrite.
- [ ] Layout tested at 320px, 375px, 768px, 1024px, 1440px. Menu, bag, admin mobile bar and checkout form remain usable.
- [ ] Cross-origin requests return valid Access-Control-Allow-Origin for the actual frontend URL; no credentials leak to browser.

## Release blockers

Do not declare production commerce readiness until you implement and test server carts, orders, checkout quote/commit, inventory reservation, payment creation/verification/webhooks, real order history, and admin management routes. All are documented in `BACKEND_GAPS.md`.
