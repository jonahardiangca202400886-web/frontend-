import test from 'node:test';
import assert from 'node:assert/strict';
import { peso, categoryOf, getPrice, cleanUrl } from '../src/utils/format.js';
test('PHP catalog price formatting', () => { assert.match(peso(59990), /59,990/); });
test('variant price takes priority over base price', () => { assert.equal(getPrice({base_price:30000},{price:33000}),33000); });
test('model filters derive from model, not invented database category', () => { assert.equal(categoryOf({model:'iPhone 17 Pro'}),'Pro'); assert.equal(categoryOf({model:'iPhone 16 Plus'}),'Plus'); assert.equal(categoryOf({model:'iPhone 15'}),'Standard'); });
test('unsafe image protocols are discarded', () => { assert.equal(cleanUrl('javascript:alert(1)'),null); assert.equal(cleanUrl('data:image/svg+xml,abc'),null); assert.equal(cleanUrl('https://example.com/p.png'),'https://example.com/p.png'); });
